/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empleadohijos;

public class Empleado {


    private final String nombre;
    private final int categoria;
    private final double sueldoBasico;
    private final int numeroHijos;

    private double bonificacionCategoria;
    private double bonificacionHijos;
    private double sueldoNeto;

    /**
     * Constructor para inicializar un empleado con sus datos.
     * @param nombre Nombre del empleado
     * @param categoria Categoría del empleado (entero)
     * @param sueldoBasico Sueldo básico del empleado
     * @param numeroHijos Número de hijos del empleado
     */
    public Empleado(String nombre, int categoria, double sueldoBasico, int numeroHijos) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.sueldoBasico = sueldoBasico;
        this.numeroHijos = numeroHijos;
        calcularBonificaciones();
    }

    /**
     * Método privado para calcular las bonificaciones y sueldo neto según las reglas dadas.
     */
    private void calcularBonificaciones() {
        // Bonificación por categoría
        bonificacionCategoria = switch (categoria) {
            case 1 -> sueldoBasico * 0.12;
            case 2 -> sueldoBasico * 0.10;
            case 3 -> sueldoBasico * 0.08;
            default -> sueldoBasico * 0.06;
        };

        // Bonificación por hijos
        if (numeroHijos <= 3) {
            bonificacionHijos = numeroHijos * 20;
        } else if (numeroHijos <= 6) {
            bonificacionHijos = numeroHijos * 30;
        } else {
            bonificacionHijos = numeroHijos * 40;
        }

        // Sueldo neto
        sueldoNeto = sueldoBasico + bonificacionCategoria + bonificacionHijos;
    }

    /**
     * Método para mostrar la información del empleado y sus cálculos.
     */
    public void mostrarInformacion() {
        System.out.println("Empleado: " + nombre);
        System.out.println("Categoría: " + categoria);
        System.out.println("Sueldo básico: S/ " + sueldoBasico);
        System.out.println("Número de hijos: " + numeroHijos);
        System.out.println("Bonificación por categoría: S/ " + bonificacionCategoria);
        System.out.println("Bonificación por hijos: S/ " + bonificacionHijos);
        System.out.println("Sueldo neto: S/ " + sueldoNeto);
        System.out.println("-----------------------------");
    }
}

