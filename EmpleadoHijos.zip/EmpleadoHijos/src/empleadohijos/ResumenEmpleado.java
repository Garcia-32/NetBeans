/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empleadohijos;

import java.util.Scanner;

public class ResumenEmpleado {

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese el número de empleados: ");
            int n = sc.nextInt();
            sc.nextLine(); // limpiar buffer
            
            Empleado[] empleados = new Empleado[n];
            
            for (int i = 0; i < n; i++) {
                System.out.println("Empleado #" + (i + 1));
                
                System.out.print("Ingrese nombre: ");
                String nombre = sc.nextLine();
                
                System.out.print("Ingrese categoría (entero): ");
                int categoria = sc.nextInt();
                
                System.out.print("Ingrese sueldo básico: ");
                double sueldoBasico = sc.nextDouble();
                
                System.out.print("Ingrese número de hijos: ");
                int numeroHijos = sc.nextInt();
                sc.nextLine(); // limpiar buffer
                
                empleados[i] = new Empleado(nombre, categoria, sueldoBasico, numeroHijos);
            }
            
            System.out.println("\nResumen de empleados:");
            for (Empleado e : empleados) {
                e.mostrarInformacion();
            }
        }
    }
}


