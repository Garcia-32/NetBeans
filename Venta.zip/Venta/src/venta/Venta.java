/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package venta;


// Se genera la clase Venta para manejar la información de cada venta
public class Venta {


    private final String cliente;
    private final String marca;
    private final int cantidad;
    private final double precioUnitario;
    private double monto;
    private double descuento;
    private double neto;

    // Constructor
    public Venta(String cliente, String marca, int cantidad) {
        this.cliente = cliente;
        this.marca = marca;
        this.cantidad = cantidad;
        this.precioUnitario = obtenerPrecioUnitario(marca);
        calcularMontos();
    }

    // Método para obtener el precio unitario según la marca
    private double obtenerPrecioUnitario(String marca) {
        switch (marca.toLowerCase()) {
            case "d’onofrio", "donofrio" -> {
                return 20;
            }
            case "motta" -> {
                return 19;
            }
            case "todinno" -> {
                return 18;
            }
            case "naval" -> {
                return 9;
            }
            case "santa claus" -> {
                return 11;
            }
            case "doña pepa", "dona pepa" -> {
                return 10;
            }
            default -> {
                System.out.println("Marca no reconocida. Precio unitario 0.");
                return 0;
            }
        }
    }

    // Método para calcular monto, descuento y neto
    private void calcularMontos() {
        monto = precioUnitario * cantidad;
        if (cantidad > 20) {
            descuento = monto * 0.10; // 10% de descuento
        } else {
            descuento = 0;
        }
        neto = monto - descuento;
    }

    // Método para mostrar la información de la venta
    public void mostrarInformacion() {
        System.out.println("Cliente: " + cliente);
        System.out.println("Marca: " + marca);
        System.out.println("Cantidad: " + cantidad);
        System.out.println("Precio Unitario: S/ " + precioUnitario);
        System.out.println("Monto: S/ " + monto);
        System.out.println("Descuento: S/ " + descuento);
        System.out.println("Neto a pagar: S/ " + neto);
        System.out.println("-----------------------------");
    }
}



