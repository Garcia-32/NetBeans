/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package venta;

import java.util.Scanner;

public class Main {
   
  
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese el número de ventas a registrar: ");
            int n = sc.nextInt();
            sc.nextLine(); // Limpiar buffer
            
            Venta[] ventas = new Venta[n];
            
            for (int i = 0; i < n; i++) {
                System.out.println("Venta #" + (i + 1));
                System.out.print("Ingrese nombre del cliente: ");
                String cliente = sc.nextLine();
                
                System.out.print("Ingrese marca del panetón: ");
                String marca = sc.nextLine();
                
                System.out.print("Ingrese cantidad de panetones: ");
                int cantidad = sc.nextInt();
                sc.nextLine(); // Limpiar buffer
                
                ventas[i] = new Venta(cliente, marca, cantidad);
                System.out.println();
            }
            
            System.out.println("Resumen de ventas:");
            for (Venta v : ventas) {
                v.mostrarInformacion();
            }
        }
    }
}